const initialState = {
	first_name: 'Aidos',
	last_name: 'Kuanyshev'
}

export default function user(state = initialState) {
	return state
}
