export const LOAD_NAME = 'LOAD_NAME'
