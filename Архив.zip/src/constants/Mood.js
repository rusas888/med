export const SET_MOOD = 'SET_MOOD'
export const SET_DATE = 'SET_DATE'